package com.rb.elite.non_rto_fragments.adapter;

import com.rb.elite.core.model.InsuranceCompanyEntity;

/**
 * Created by IN-RB on 14-12-2018.
 */

public interface IInsurer {

    void getInsurer( InsuranceCompanyEntity entity);
}
