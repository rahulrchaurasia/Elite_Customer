package com.rb.elite.core.model;

public class VariantEntity {
    /**
     * Variant : ALPSV 4/88
     * VariantID : 12
     */

    private String Variant;
    private int VariantID;

    public String getVariant() {
        return Variant;
    }

    public void setVariant(String Variant) {
        this.Variant = Variant;
    }

    public int getVariantID() {
        return VariantID;
    }

    public void setVariantID(int VariantID) {
        this.VariantID = VariantID;
    }
}