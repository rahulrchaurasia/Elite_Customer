package com.rb.elite.feedback;

import com.rb.elite.core.model.CompleteOrderEntity;

/**
 * Created by Rajeev Ranjan on 09/01/2019.
 */

public interface ICompOrderData {

    void getOrderData(CompleteOrderEntity completeOrderEntity);
}
