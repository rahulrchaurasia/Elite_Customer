package com.rb.elite.core.response;

import com.rb.elite.core.APIResponse;

/**
 * Created by IN-RB on 05-02-2018.
 */

public class CommonResponse extends APIResponse {



}
