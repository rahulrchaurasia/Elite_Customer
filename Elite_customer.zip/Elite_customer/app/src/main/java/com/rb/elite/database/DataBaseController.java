package com.rb.elite.database;

import android.content.Context;



/**
 * Created by Rajeev Ranjan on 02/02/2018.
 */

public class DataBaseController {
    Context mContext;



    public DataBaseController(Context mContext) {
        this.mContext = mContext;

    }




}
