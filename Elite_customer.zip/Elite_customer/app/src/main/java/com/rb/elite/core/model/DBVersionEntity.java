package com.rb.elite.core.model;

public class DBVersionEntity {

    private int DB_version;
    private int City_Version;

    public int getDB_version() {
        return DB_version;
    }

    public void setDB_version(int DB_version) {
        this.DB_version = DB_version;
    }

    public int getCity_Version() {
        return City_Version;
    }

    public void setCity_Version(int City_Version) {
        this.City_Version = City_Version;
    }
}