package com.rb.elite.core.response;

import com.rb.elite.core.APIResponse;

/**
 * Created by Rajeev Ranjan on 15/07/2019.
 */
public class SaveChatResponse extends APIResponse {
}
