package com.rb.elite.core.model;

/**
 * Created by IN-RB on 14-11-2018.
 */

public class MakeX {

   private String Make;
    private  int MakeID;

    public String getMake() {
        return Make;
    }

    public void setMake(String make) {
        Make = make;
    }

    public int getMakeID() {
        return MakeID;
    }

    public void setMakeID(int makeID) {
        MakeID = makeID;
    }



}
