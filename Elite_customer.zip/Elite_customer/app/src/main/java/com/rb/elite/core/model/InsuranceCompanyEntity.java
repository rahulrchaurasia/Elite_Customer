package com.rb.elite.core.model;

public class InsuranceCompanyEntity {
    /**
     * Motor_Insurance_Id : 1
     * Motor_Insurance_Name : THE ORIENTAL INSURANCE COMPANY LIMITED
     */

    private int Insurance_Id;
    private String Insurance_Name;

    public int getInsurance_Id() {
        return Insurance_Id;
    }

    public void setInsurance_Id(int insurance_Id) {
        Insurance_Id = insurance_Id;
    }

    public String getInsurance_Name() {
        return Insurance_Name;
    }

    public void setInsurance_Name(String insurance_Name) {
        Insurance_Name = insurance_Name;
    }


}