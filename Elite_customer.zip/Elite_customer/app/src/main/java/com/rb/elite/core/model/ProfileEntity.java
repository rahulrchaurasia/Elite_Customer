package com.rb.elite.core.model;

public  class ProfileEntity {
        /**
         * make : Honda
         * model : i20
         * name : Daniyal
         * emailid : shaikhdani216@gmail.com
         * mobile : 9833797088
         * city_id : Mumbai
         * state_id : Maharashtra
         * area : Kurla
         * pincode : 400095
         * vehicle_no : MH02dv3281
         * policy_no : 
         */

        private String make;
        private String model;
        private String name;
        private String emailid;
        private String mobile;
        private String city_id;
        private String state_id;
        private String area;
        private String pincode;
        private String vehicle_no;
        private String policy_no;

        public String getMake() {
            return make;
        }

        public void setMake(String make) {
            this.make = make;
        }

        public String getModel() {
            return model;
        }

        public void setModel(String model) {
            this.model = model;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getEmailid() {
            return emailid;
        }

        public void setEmailid(String emailid) {
            this.emailid = emailid;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getCity_id() {
            return city_id;
        }

        public void setCity_id(String city_id) {
            this.city_id = city_id;
        }

        public String getState_id() {
            return state_id;
        }

        public void setState_id(String state_id) {
            this.state_id = state_id;
        }

        public String getArea() {
            return area;
        }

        public void setArea(String area) {
            this.area = area;
        }

        public String getPincode() {
            return pincode;
        }

        public void setPincode(String pincode) {
            this.pincode = pincode;
        }

        public String getVehicle_no() {
            return vehicle_no;
        }

        public void setVehicle_no(String vehicle_no) {
            this.vehicle_no = vehicle_no;
        }

        public String getPolicy_no() {
            return policy_no;
        }

        public void setPolicy_no(String policy_no) {
            this.policy_no = policy_no;
        }
    }