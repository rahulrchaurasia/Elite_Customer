package com.rb.elite.core.model;

public  class RateDisplayEntity {
        /**
         * comment : Nice Service
         * rating : 2.5
         */

        private String comment;
        private float rating;

        public String getComment() {
            return comment;
        }

        public void setComment(String comment) {
            this.comment = comment;
        }

        public float getRating() {
            return rating;
        }

        public void setRating(float rating) {
            this.rating = rating;
        }
    }