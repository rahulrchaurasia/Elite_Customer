package com.rb.elite.core.model;

import java.util.List;

public  class AllCityData {
        private List<AllCityEntity> AllCities;

        public List<AllCityEntity> getAllCities() {
            return AllCities;
        }

        public void setAllCities(List<AllCityEntity> AllCities) {
            this.AllCities = AllCities;
        }


    }