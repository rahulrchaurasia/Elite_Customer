package com.rb.elite.rto_fragment.adapter;

import com.rb.elite.core.model.RtoCityMain;

/**
 * Created by Nilesh Birhade on 29-11-2018.
 */

public interface IRTOCity {

    void getRTOCity( RtoCityMain entity);
}
