package com.rb.elite.core.model;

public  class DocResultEntity {
        /**
         * status : 1
         * path : http://elite.rupeeboss.com/uploads/14/2.png
         */


        private int status;
        private String path;

        public int getStatusX() {
            return status;
        }

        public void setStatusX(int statusX) {
            this.status = statusX;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }
    }

